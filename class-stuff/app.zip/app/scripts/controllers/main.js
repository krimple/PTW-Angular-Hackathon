(function() {
  'use strict';

  angular.module('classStuffApp')
    .controller('MainCtrl', function ($scope, $log) {
      $scope.tasks = [
        {
          complete: false,
          description: 'Do the dishes'
        }
      ];

      $scope.addTask = function(description) {
        $scope.tasks.push({
          complete: false,
          description: description
        });

        $log.debug('added a new task');
      };
    });
}());

