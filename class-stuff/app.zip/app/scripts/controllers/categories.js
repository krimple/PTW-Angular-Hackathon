'use strict';

angular.module('classStuffApp')
  .controller('CategoriesCtrl', function ($scope) {

  });
